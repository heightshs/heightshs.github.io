
 Instructions for running jGRASP are in  help/contents.html .

 Be sure to read the known bugs before running.

