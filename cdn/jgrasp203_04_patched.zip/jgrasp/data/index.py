s
compiler environments
Python 3 - generic
      &#  (    K
Python 2 - generic
  (   &#  *2  !/
Python 2 - Enthought Canopy
  22  &$  +J  !\
